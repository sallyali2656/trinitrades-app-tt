# TriniTrades App TT

A simple MVP React app to register tradespeople and customers in Trinidad & Tobago.